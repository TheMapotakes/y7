Well, Contributing is a thing, so I might as well lay down some rules. I'm laid back about how CloudLink should be managed, but here's my 5-rule philosophy:

1. Be respectful of other contributors. (Don't be a jerk!)
2. Follow your local gov't laws. (Don't do anything illegal!)
3. Follow the golden rule: "Treat people you the way you want to be treated" (Be nice!)
5. And please, English only comments. (Use a translator if needed.)
